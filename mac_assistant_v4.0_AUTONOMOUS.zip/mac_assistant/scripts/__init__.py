"""Scripts module"""
from .applescript_bridge import AppleScriptBridge

__all__ = ['AppleScriptBridge']
