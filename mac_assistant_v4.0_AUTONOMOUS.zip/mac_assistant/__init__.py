"""
Mac Remote Access Assistant
AI-powered assistant to manage your Mac apps and activities
"""

__version__ = "1.0.0"
